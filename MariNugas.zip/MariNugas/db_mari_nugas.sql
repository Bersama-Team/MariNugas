-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2023 at 12:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_mari_nugas`
--

-- --------------------------------------------------------

--
-- Table structure for table `tugas`
--

CREATE TABLE `tugas` (
  `id` int(11) NOT NULL,
  `judul` text NOT NULL,
  `deskripsi` text NOT NULL,
  `tenggat_tanggal` text NOT NULL,
  `tenggat_jam` text NOT NULL,
  `status` enum('unfinished','finished') DEFAULT 'unfinished'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tugas`
--

INSERT INTO `tugas` (`id`, `judul`, `deskripsi`, `tenggat_tanggal`, `tenggat_jam`, `status`) VALUES
(17, 'Tugas 1 FBD', 'Menginstall Apache Hive', '20-12-2023', '23:59', 'unfinished'),
(18, 'Tugas 2 FBD', 'Kerjakan Course 2', '21-12-2023', '22:59', 'unfinished'),
(19, 'Tubes Praktikum Mobile', 'Membuat Aplikasi Sederhana Dengan Mengimplementasikan Rest API dan PHP MYSQL', '20-12-2023', '23:59', 'unfinished'),
(20, 'Tubes Mobile', 'Membuat Aplikasi Sederhana', '21-12-2023', '23:59', 'unfinished'),
(21, 'Tubes FBD', 'Mining Data', '27-12-2023', '22:0', 'unfinished'),
(22, 'Tubes IoT', 'Membuat Website Dengan Server Sendiri', '28-12-2023', '21:59', 'unfinished'),
(23, 'Tubes Desain Interaksi', 'Membuat Tampilan dan Prototype Aplikasi ', '22-12-2023', '8:30', 'unfinished'),
(24, 'Quiz Desain Interaksi', 'Quiz kedua lewat kahoot', '25-12-2023', '19:30', 'unfinished'),
(25, 'Tugas IoT', 'Membuat Lampu LED Blink Nyala', '24-12-2023', '23:59', 'unfinished'),
(26, 'Tugas ML', 'Membuat Model Dataset Untuk Diabetes', '30-12-2023', '23:59', 'unfinished');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tugas`
--
ALTER TABLE `tugas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tugas`
--
ALTER TABLE `tugas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
