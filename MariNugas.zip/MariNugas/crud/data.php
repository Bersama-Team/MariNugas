<?php 

    require_once('helper.php');

    $query = "SELECT * FROM tugas
    ORDER BY
        CASE 
            WHEN status = 'unfinished' THEN 1
            WHEN status = 'finished' THEN 2
            ELSE 3
        END,
        tenggat_tanggal ASC,
        tenggat_jam ASC;
    ";
    $sql = mysqli_query($db_connect, $query);

    if ($sql) {
    
        $result = array();
        while ($row = mysqli_fetch_array($sql)) {
            array_push( $result, array(
                'id' => $row['id'],
                'judul' => $row['judul'],
                'deskripsi'=> $row['deskripsi'],
                'tenggat_tanggal'=> $row['tenggat_tanggal'],
                'tenggat_jam'=> $row['tenggat_jam'],
                'status'=> $row['status'],
            ));
        
        }
        echo json_encode( array('tugas' => $result));
    }

?>