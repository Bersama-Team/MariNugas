<?php 

    require_once('helper.php');
    parse_str(file_get_contents('php://input'), $value);

    $id = $value['id'];
    $judul = $value['judul'];
    $deskripsi = $value['deskripsi'];
    $tenggat_tanggal = $value['tenggat_tanggal'];
    $tenggat_jam = $value['tenggat_jam'];
    $status = $value['status'];


    $query = "UPDATE tugas
    SET judul = '$judul', 
        deskripsi = '$deskripsi', 
        tenggat_tanggal = '$tenggat_tanggal', 
        tenggat_jam = '$tenggat_jam',
        status = '$status'
    WHERE id = '$id';
    ";
    
    $sql = mysqli_query($db_connect, $query);

    if ($sql) {

        echo json_encode( array('message' => 'Tugas berhasil diupdate!'));
    } else {
        echo json_encode( array('message' => 'Error!'));

    }

?>