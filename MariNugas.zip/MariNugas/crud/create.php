<?php 

    require_once('helper.php');

    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $tenggat_tanggal = $_POST['tenggat_tanggal'];
    $tenggat_jam = $_POST['tenggat_jam'];
    $status = $_POST['status'];


    $query = "INSERT INTO tugas (judul, deskripsi, tenggat_tanggal, tenggat_jam, status)
    VALUES ('$judul', '$deskripsi', '$tenggat_tanggal', '$tenggat_jam', '$status')";
    
    $sql = mysqli_query($db_connect, $query);

    if ($sql) {

        echo json_encode( array('message' => 'Tugas berhasil ditambahkan!'));
    } else {
        echo json_encode( array('message' => 'Error!'));

    }

?>